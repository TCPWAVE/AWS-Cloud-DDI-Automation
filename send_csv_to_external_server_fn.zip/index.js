exports.handler = (event, context, callback) => {
    
  var orgName = "Internal";
  var domainName = "tcpwave1.com";
	
	var ftpHost = "50.63.141.243";
	var ftpPort = "21";
	var ftpUser = "twcwrite";
	var ftpPassword = "Delt@Stream";
	var ftpPath = "/aws-ec2-changes.csv";
	var rotationDuration = 86400000; //24 hours
    
	var Client = require('ftp');
	var fs = require('fs');
  var AWS = require('aws-sdk');
  var cData = JSON.stringify(event, null, 2);
  var arr = [];
	var stateStr = '';
	
  if(cData)
  {
      arr = cData.split(" ");
  }
  console.log('Received event:', cData); 
  var instanceId = arr[0].substring(1);
  var status = arr[1].substring(0, arr[1].length-1);
  
  console.log("Status:"+status);
  
  var ec2 = new AWS.EC2();
  var dynamodb = new AWS.DynamoDB(); 
  
  var params = { InstanceIds: [instanceId]};
  var name;
  var ip;
  ec2.describeInstances(params, function(err, data) {
  if (err) 
  {
    console.log(err, err.stack); 
  }// an error occurred
  else   
  {
    var res = data.Reservations;
    for(var i =0; i<res.length; i++)
    {
      var instances = res[i].Instances;
       console.log("Instances:"+instances);
      for(var j =0; i<instances.length; i++)
      {
        console.log("Instance:"+i);
        var instance = instances[j];
        ip = instance.PrivateIpAddress;
        var tags = instance.Tags;
        
        for(var k =0; k<tags.length; k++)
        {
          var tag = tags[k];
          if(tag.Key == "TWC Organization")
          {
            orgName = tag.Value;
          }
          else if(tag.Key == "TWC Domain")
          {
            domainName = tag.Value;
          }
          else if(tag.Key == "TWC DNS Name")
          {
            name = tag.Value;
          }
        }
        console.log("Organization:"+orgName);
        console.log("Domain:"+domainName);
        if(instance)
        {
          break;
        }
      }
      if(instances)
      {
        break;
      }
    }
    
  var ipArr = ip.split(".");
  if(name == undefined || name == "")
      {
        name = "ip-"+ipArr[0]+"-"+ipArr[1]+"-"+ipArr[2]+"-"+ipArr[3];
      }
  console.log("Instance:"+name+" "+ip);  
    
  
  if(status == 'running')
  {
    stateStr = 'Add';
  }
  else
  {
    stateStr = 'Delete';
  }   
   console.log("Event::"+event);
	
	 var currentTime = new Date().getTime();
    var t = currentTime - rotationDuration;
   	var sParams = {
    TableName: "ec2_state_change",
    FilterExpression: "#timestampvalue <= :val",
    ExpressionAttributeValues: {":val": {"N": ''+t}},
    ExpressionAttributeNames: {"#timestampvalue": "timestamp"}
   };
   dynamodb.scan(sParams, function(err, data) {
     if (err) {
         console.log("DynamoDB data read error");
         console.log(err, err.stack); // an error occurred
     }
     else     
     {
       var itms = data.Items;
       var paramsArr = [];
       for(var k=0; k< itms.length; k++)
       {
         var p = {
                    DeleteRequest : {
                        Key : {
                            'timestamp' :{
                                   'N': itms[k].timestamp.N   
                                }
                        }
                    }
                };
        paramsArr.push(p);
       }
       
       var params = {
                    RequestItems : {
                        'ec2_state_change' : paramsArr
                    }
                };
                
      dynamodb.batchWriteItem(params, function(err, data) {
          if (err && paramsArr.length>0) {
              console.log('Batch delete unsuccessful ...');
              console.log(err, err.stack); // an error occurred
          } else {
              console.log('Batch delete successful ...');
              console.log(data); // successful response
              
	//Add to Dynamodb
   var addParams = {
            TableName:"ec2_state_change",
            Item:{
                timestamp : { N:''+currentTime},
                operation: { S:stateStr},
                ip : { S:ip},
                name: { S:name}
            }
        };
        
 
  dynamodb.putItem(addParams, function(err, data) {
   if (err) {
       console.log("DynamoDB data add error");
       console.log(err, err.stack); // an error occurred
   }
   else {
       console.log("DynamoDB data added");
       console.log(data);         
       
	
	
	//Read from table and write to file
	var scanParams = {
                      TableName: "ec2_state_change"
                     };
 dynamodb.scan(scanParams, function(err, data) {
   if (err) {
       console.log("DynamoDB data read error");
       console.log(err, err.stack); // an error occurred
   }
   else     
   {
         var str = '';
         console.log("DynamoDB data");
         var items = data.Items;
         items.sort(function (a, b) {
          return a.timestamp.N - b.timestamp.N;
        });
         for(var i=0; i<items.length; i++)
         {
           var item = items[i];
           var d = new Date(Number(item.timestamp.N));
           str = str+item.operation.S+" "+item.ip.S+" "+item.name.S+" ("+d.toString()+")\n";
         }
         console.log("File content:"+str);
         fs.writeFileSync('/tmp/twcEC2StateChanges.csv', str, function (err) {
         if (err) throw err;
         console.log('Saved!');
  });
    
   
	    
    	var config = {
            host: ftpHost,
            port: ftpPort,
            user: ftpUser,
            password: ftpPassword
        };
    
    	var c = new Client();
    	  c.on('ready', function() {
    		c.put('/tmp/twcEC2StateChanges.csv', ftpPath, function(err) {
    		  if (err) console.log(err);
    		  c.end();
    		});
    	  });
    	  c.connect(config);
    	  }
    	});
       }

 });
    }
  }); 
  }
  });
  }
  });
 
  callback(null, 'EC2InstanceStateChange execution completed.');
};